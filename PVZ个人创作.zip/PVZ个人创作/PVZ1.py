import pygame
import random
import sys
import time

get_event_queue=[]
def add_event(event):
    global get_event_queue
    get_event_queue.append(event)
DRAW=1
class Event():
    def __init__(self,code):
        self.code=code

class Listener():
    def __init__(self,code):
        self.code=code
    def post(self,event):
        add_event(event)
    def listen(self,event):
        pass

class EntityLike(Listener):
    def __init__(self,image,rect):
        self.image=image
        self.rect=rect
    def listen(self,event):
        if event.code==DRAW:
            self.draw()

# 初始化 pygame
pygame.init()
FPS=120
# 设置窗口大小
screen_width = 1000
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
# 设置窗口标题
pygame.display.set_caption("植物大战僵尸射击版")

# 加载背景图像
bg_day = pygame.image.load("images/longbackground.png")
# 缩放背景图像以适应窗口大小
bg_day = pygame.transform.scale(bg_day, (3200, screen_height))
bg_night = pygame.image.load("images/Nightfrontyard.png")
bg_night = pygame.transform.scale(bg_night, (screen_width, screen_height))
screen.blit(bg_day, (-200, 0))

frame=[]
for i in range(1,19):
    fm_cjs=pygame.image.load(f"images/commonjs/cjs{i}.png")
    frame.append(fm_cjs)



pygame.font.init()
FONTS = [pygame.font.Font(pygame.font.get_default_font(), font_size) for font_size in [48, 36, 24]]
class ZombieManager(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.zombie_list=[]
        self.move_speed=0.1
    def gen_new_zombie(self):
        gen=random.choice([425,315,230,125,25])
        if self.zombie_list==[]:
            self.zombie_list.append(Zombie(100,gen))
        else:
            if self.zombie_list[-1].x<950:
                self.zombie_list.append(Zombie(1000,gen))
    def move(self):
        for js in self.zombie_list:
            js.move()
    def draw(self):
        for jsd in self.zombie_list:
            jsd.draw()
class Zombie(ZombieManager):
    def __init__(self,x,y):
        super().__init__()
        self.style=0
        self.x=x
        self.y=y
        self.HP=270
        self.move_speed=0.1
        self.cjsindex=0
        self.image=pygame.image.load("images/commonjs/cjs1.png")
    def draw(self):
        if self.style==0 and not over:
            self.cjsindex+=0.05
            cjsblit=int(self.cjsindex%len(frame))
            screen.blit(frame[cjsblit],(self.x,screen_height-(self.y+frame[cjsblit].get_height())))
            zombie_rect = fm_cjs.get_rect()
            zombie_rect.x = self.x
            zombie_rect.y = self.y
            self.image=frame[cjsblit]
        elif self.style==0 and over:
            screen.blit(self.image,(self.x,screen_height-(self.y+self.image.get_height())))
        elif self.style==1 and over:
            self.y=230
            self.cjsindex+=0.05
            cjsblit=int(self.cjsindex%len(frame))
            screen.blit(frame[cjsblit],(self.x,screen_height-(self.y+frame[cjsblit].get_height())))
            zombie_rect = fm_cjs.get_rect()
            zombie_rect.x = self.x
            zombie_rect.y = self.y
            self.image=frame[cjsblit]
        
    def move(self):
        self.x-=self.move_speed
    def is_dead(self):
        if self.HP<=0:
            return True
        else:
            return False
    def is_end(self):
        if self.x<=30:
            self.style=1
            return True
        else:
            return False
        
cursor_image_path = "images/OIP-C (1).jfif"
cursor_image = pygame.image.load(cursor_image_path).convert_alpha()
cursor_image = pygame.transform.scale(cursor_image, (cursor_image.get_width() // 8, cursor_image.get_height() // 8))
cursor_size = cursor_image.get_size()
cursor_surface = pygame.Surface(cursor_size, pygame.SRCALPHA)
cursor_surface.blit(cursor_image, (0, 0))
hotspot_x = cursor_size[0] // 2
hotspot_y = cursor_size[1] // 2
custom_cursor = pygame.cursors.Cursor((hotspot_x, hotspot_y), cursor_surface)
pygame.mouse.set_cursor(custom_cursor)


over=False
ji=0
n=0

emg=ZombieManager()
while True:
    n+=1
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1:
                screen.blit(bg_day,(-200,0))
            if event.key == pygame.K_2:
                screen.blit(bg_night,(0,0))
    if not over:
        screen.blit(bg_day,(-1900,0))
        if n>200:
            emg.gen_new_zombie()
            emg.move()
            emg.draw()
        for zx1 in emg.zombie_list:
            if zx1.is_end():
                over=True
                zx1.style=1
                break
            
    if ji<1 and over:
        pygame.time.delay(2000)
        for zx2 in emg.zombie_list:
                zx2.x-=20
        for i in range(99,-1,-1):
            screen.blit(bg_day,(-1700-i*2,0))
            for zx2 in emg.zombie_list:
                zx2.x+=2
            emg.draw()
            pygame.display.update()
            pygame.time.delay(10)
        ji+=1
        dayfail=pygame.image.load("images/dayfail.png")
        for i in range(1000):
            screen.blit(dayfail,(-1700,0))
            zx1.move()
            emg.draw()
            pygame.display.update()
            pygame.time.delay(2)
        go=pygame.image.load("images/gameover.png")
        dayfail2=pygame.image.load("images/dayfail2.png")
        go2=pygame.image.load("images/gameover2.png")
        go2=pygame.transform.scale(go2,(400,320))
        for i in range(500):
            screen.blit(dayfail2,(-1700,0))
            for zx3 in emg.zombie_list:
                if zx3.style!=1:
                    zx3.draw()
            goo=pygame.transform.scale(go,(i,i))
            screen.blit(goo,(500-0.5*i,300-0.5*i))
            pygame.display.update()
        pygame.time.delay(2000)
        screen.blit(dayfail2,(0,0))
        for zx3 in emg.zombie_list:
                if zx3.style!=1:
                    zx3.draw()
        screen.blit(go2,(280,120))
        pygame.display.update()
    
    # 更新屏幕
    pygame.time.Clock().tick(FPS)
    pygame.display.update()
